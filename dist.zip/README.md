<img src="img/synthesistlogo.png" alt="Scale Space Synthesis" width="1024px" align="center" />

# Scale Space Synthesist

![status](https://img.shields.io/badge/status-1.0-green) ![license](https://img.shields.io/badge/license-MIT-blue)

A Free, Open Source WebGPU phase-space visualizer / particle-based morphoscope.<br />
Part of the [Scale Space](https://reddit.com/r/ScaleSpace) project.

<img src="img/Scale-Space-Synthesist-v1.0-Screenshot.png" alt="Scale Space Synthesis" width="1024px" align="center" />

*Scroll further down for more photos.*

This is a heavy optimization branch to push the framerates, improve memory/threading usage, and enables additional audiovisual fx and control. Just load a song, enable continuous randomization, and chill.

Demos:

[https://www.youtube.com/watch?v=gbVG4Wt_z_o](https://www.youtube.com/watch?v=gbVG4Wt_z_o)

[https://www.youtube.com/watch?v=u9d6SfQyXR0](https://www.youtube.com/watch?v=u9d6SfQyXR0)

[https://www.youtube.com/watch?v=k5BFctwdXHI&t=25s](https://www.youtube.com/watch?v=k5BFctwdXHI&t=25s)

## Build & Run

This is not using the vite build of the original to make way for SharedArrayBuffer and more complex web worker support. It can be done but this was easier for me.

From the same directory: `npm i -g tinybuild` then `tinybuild`

For newbies: 

Download VSCode/VSCodium

Install NodeJS

Download and open this repository in VSCode

In the VSCode terminal type the above two commands, open the local server.

To enable SharedArrayBuffer support you need the following headers to be sent over the server:

headers:

`'Cross-Origin-Opener-Policy': 'same-origin'`

`'Cross-Origin-Embedder-Policy': 'require-corp'`


Native apps require a slightly different workflow


## Keyboard shortcuts

| Keys | Action |
|---|---|
| Tab | Hide/show UI |
| Home | Return to Homepoint |
| PgUp / PgDn | Adjust tempo |
| Ctrl+S | Capture current configuration as a waypoint |
| Arrow keys | Orbital Rotation |
| Q / E | Free energy (particle count) |
| Z / X | Resolution (particle size) |
| R / T | Equilibrium (noise speed) |
| F / G | Temperature (noise intensity) |
| V / B | Coherence (attraction radius) |
| I / O | Inversion (compression) |
| N / M | Scale depth (attraction force) |
| K / L | Half-life (particle lifespan) |
| Doouble Left-click canvas | Open Parameters radial menu |
| Double Right-click canvas | Open Visuals radial menu |
| Middle-click canvas | Open Config radial menu |

*More controls information available in the 'Controls' panel in the application.*

## Tutorials

* [Video demo- How to use Panels](https://www.reddit.com/r/ScaleSpace/comments/1svvcox/scale_space_bioclast_alpha_01_release_notes/)
* [Video demo- How to use Radials](https://www.reddit.com/r/ScaleSpace/comments/1t2sugd/scale_space_bioclast_alpha_02_release_notes/)
* [Video tour through Scale Space](https://www.reddit.com/r/ScaleSpace/comments/1t4hz9i/heres_my_most_recent_tour_through_scale_space/)
* [Two hours of exploration in Scale Space](https://www.reddit.com/r/ScaleSpace/comments/1szztpr/heres_the_full_2_hour_long_emergent_cellular/)

# Screenshots

All screenshots are unedited. Differences in scanlines and backgrounds come from settings in Scale Space Synthesist.

<img src="img/Screenshot 2026-05-09 073620.png" width="100%" />
<img src="img/Screenshot 2026-05-09 073933.png" width="100%" />
<img src="img/Screenshot 2026-05-09 074014.png" width="100%" />
<img src="img/Screenshot 2026-05-09 074456.png" width="100%" />
<img src="img/Screenshot 2026-05-09 074555.png" width="100%" />
<img src="img/Screenshot 2026-05-09 074634.png" width="100%" />
<img src="img/Screenshot 2026-05-09 074749.png" width="100%" />
<img src="img/Screenshot 2026-05-09 074846.png" width="100%" />
<img src="img/Screenshot 2026-05-09 075919.png" width="100%" />
<img src="img/Screenshot 2026-05-09 080020.png" width="100%" />
<img src="img/Screenshot 2026-05-09 080039.png" width="100%" />

<img src="img/scalespace_SS-PD3VIK_2026-05-11T00-42-48.png" width="100%" />
<img src="img/scalespace_SS-PD3VIK_2026-05-11T00-46-30.png" width="100%" />
<img src="img/scalespace_SS-UH5MWD_2026-05-11T01-03-32.png" width="100%" />
<img src="img/scalespace_SS-WNWP8Y_2026-05-11T01-12-09.png" width="100%" />
<img src="img/scalespace_SS-9RTSWU_2026-05-11T01-30-52.png" width="100%" />
<img src="img/scalespace_SS-PD3VIK_2026-05-11T01-34-41.png" width="100%" />
<img src="img/scalespace_SS-DICTUY_2026-05-11T01-37-58.png" width="100%" />
<img src="img/scalespace_SS-NQKVF3_2026-05-11T12-16-05.png" width="100%" />

<img src="img/Screenshot 2026-05-12 202624.png" width="100%" />
<img src="img/Screenshot 2026-05-12 202714.png" width="100%" />
<img src="img/Screenshot 2026-05-12 202733.png" width="100%" />
<img src="img/Screenshot 2026-05-12 202805.png" width="100%" />
<img src="img/Screenshot 2026-05-12 203323.png" width="100%" />
<img src="img/Screenshot 2026-05-12 203424.png" width="100%" />
<img src="img/Screenshot 2026-05-12 203622.png" width="100%" />
<img src="img/Screenshot 2026-05-12 204410.png" width="100%" />
<img src="img/Screenshot 2026-05-12 204418.png" width="100%" />
<img src="img/Screenshot 2026-05-12 204437.png" width="100%" />
<img src="img/Screenshot 2026-05-12 205132.png" width="100%" />
<img src="img/Screenshot 2026-05-12 210026.png" width="100%" />
<img src="img/Screenshot 2026-05-12 223832.png" width="100%" />
<img src="img/Screenshot 2026-05-12 223952.png" width="100%" />
<img src="img/Screenshot 2026-05-12 224227.png" width="100%" />
<img src="img/Screenshot 2026-05-12 225231.png" width="100%" />

<img src="img/Screenshot 2026-05-13 112616.png" width="100%" />
<img src="img/Screenshot 2026-05-13 112715.png" width="100%" />
<img src="img/Screenshot 2026-05-13 112830.png" width="100%" />
<img src="img/Screenshot 2026-05-13 113429.png" width="100%" />
<img src="img/Screenshot 2026-05-13 114103.png" width="100%" />
<img src="img/Screenshot 2026-05-13 114459.png" width="100%" />
<img src="img/Screenshot 2026-05-13 114639.png" width="100%" />
<img src="img/Screenshot 2026-05-13 210708.png" width="100%" />

<img src="img/Screenshot 2026-05-14 124716.png" width="100%" />
<img src="img/Screenshot 2026-05-14 184434.png" width="100%" />
<img src="img/Screenshot 2026-05-14 194121.png" width="100%" />

<img src="img/scalespace_SS-6NKGC7_2026-05-15T00-46-05.png" width="100%" />
<img src="img/scalespace_SS-IUWNWN_2026-05-15T00-47-22.png" width="100%" />
<img src="img/scalespace_SS-LWTI1V_2026-05-15T00-47-50.png" width="100%" />
<img src="img/scalespace_SS-7TZO93_2026-05-15T00-48-04.png" width="100%" />
<img src="img/scalespace_SS-I4E9KO_2026-05-15T00-48-13.png" width="100%" />
<img src="img/scalespace_SS-SW441D_2026-05-15T00-48-41.png" width="100%" />
<img src="img/scalespace_SS-PC958_2026-05-15T00-50-27.png" width="100%" />
<img src="img/scalespace_SS-WHY9M5_2026-05-15T00-50-57.png" width="100%" />
<img src="img/scalespace_SS-VQ47XP_2026-05-15T00-52-53.png" width="100%" />
<img src="img/scalespace_SS-JY8ZP4_2026-05-15T00-54-51.png" width="100%" />
<img src="img/scalespace_SS-2XOKPQ_2026-05-15T00-57-04.png" width="100%" />
<img src="img/scalespace_SS-HCF2E6_2026-05-15T01-01-00.png" width="100%" />
<img src="img/scalespace_SS-FDOWBK_2026-05-15T01-02-06.png" width="100%" />
<img src="img/scalespace_SS-GM7EMO_2026-05-15T01-02-28.png" width="100%" />
<img src="img/scalespace_SS-GUZL66_2026-05-15T01-05-35.png" width="100%" />
<img src="img/scalespace_SS-INOO0T_2026-05-15T01-06-38.png" width="100%" />
<img src="img/scalespace_SS-JJFR2L_2026-05-15T01-07-18.png" width="100%" />
<img src="img/scalespace_SS-V4IBWY_2026-05-15T01-09-31.png" width="100%" />
<img src="img/Screenshot 2026-05-15 072022.png" width="100%" />
<img src="img/Screenshot 2026-05-15 075556.png" width="100%" />
<img src="img/scalespace_SS-GRCE0A_2026-05-15T12-00-57.png" width="100%" />
<img src="img/scalespace_SS-U4KNIO_2026-05-15T12-02-38.png" width="100%" />
<img src="img/Screenshot 2026-05-15 122803.png" width="100%" />
<img src="img/scalespace_SS-75FPYW_2026-05-15T20-15-50.png" width="100%" />
<img src="img/scalespace_SS-B50047_2026-05-15T21-03-42.png" width="100%" />
<img src="img/scalespace_SS-B50047_2026-05-15T21-04-09.png" width="100%" />
<img src="img/scalespace_SS-B50047_2026-05-15T21-05-42.png" width="100%" />
<img src="img/scalespace_SS-SFHIPC_2026-05-15T21-08-01.png" width="100%" />
<img src="img/scalespace_SS-8VPR0T_2026-05-15T21-10-48.png" width="100%" />
<img src="img/scalespace_SS-8VPR0T_2026-05-15T21-10-57.png" width="100%" />
<img src="img/scalespace_SS-88AYTV_2026-05-15T21-14-44.png" width="100%" />
<img src="img/scalespace_SS-L6148J_2026-05-15T21-17-38.png" width="100%" />
<img src="img/scalespace_SS-X4Z7UO_2026-05-15T21-20-12.png" width="100%" />
<img src="img/scalespace_SS-KY238F_2026-05-15T21-21-02.png" width="100%" />
<img src="img/scalespace_SS-3ZZCCE_2026-05-15T21-21-10.png" width="100%" />
<img src="img/scalespace_SS-TW65FO_2026-05-15T21-21-16.png" width="100%" />
<img src="img/scalespace_SS-UQQK9V_2026-05-15T21-21-45.png" width="100%" />
<img src="img/scalespace_SS-3T9XMI_2026-05-15T21-40-04.png" width="100%" />
<img src="img/scalespace_SS-OMV6D5_2026-05-15T21-42-27.png" width="100%" />
<img src="img/scalespace_SS-UHBZR2_2026-05-15T21-43-48.png" width="100%" />
<img src="img/scalespace_SS-DX3GA0_2026-05-15T21-45-29.png" width="100%" />
<img src="img/scalespace_SS-1KA1PG_2026-05-15T21-46-42.png" width="100%" />
<img src="img/scalespace_SS-Q7GJVF_2026-05-15T21-47-53.png" width="100%" />
<img src="img/scalespace_SS-4ITOAZ_2026-05-15T21-50-24.png" width="100%" />

<img src="img/scalespace_SS-3T9XMI_2026-05-16T00-54-55.png" width="100%" />

<img src="img/scalespace_SS-VX46SX_2026-05-17T12-17-16.png" width="100%" />
<img src="img/scalespace_SS-RRGRGO_2026-05-17T12-34-09.png" width="100%" />
<img src="img/scalespace_SS-RRGRGO_2026-05-17T12-34-24.png" width="100%" />
<img src="img/scalespace_SS-XDG46H_2026-05-17T12-40-32.png" width="100%" />
<img src="img/scalespace_SS-S41G27_2026-05-17T12-44-56.png" width="100%" />
<img src="img/scalespace_SS-AIZYCM_2026-05-17T12-49-27.png" width="100%" />
<img src="img/scalespace_SS-7W7VBE_2026-05-17T13-07-15.png" width="100%" />
<img src="img/Screenshot 2026-05-17 132410.png" width="100%" />
<img src="img/scalespace_SS-DK5UDD_2026-05-17T13-50-29.png" width="100%" />
<img src="img/scalespace_SS-U74EG_2026-05-17T13-51-38.png" width="100%" />
<img src="img/scalespace_SS-6KWR5N_2026-05-17T13-52-28.png" width="100%" />
<img src="img/scalespace_SS-XAJ9FV_2026-05-17T15-07-21.png" width="100%" />

## Contributing

Thoughtful PRs welcome. Discussion and shared waypoints at [/r/ScaleSpace](https://reddit.com/r/ScaleSpace).


[Get it on itch.io](https://setzstone.itch.io/scale-space) (early access to new features)


## License

MIT — see `LICENSE`.

